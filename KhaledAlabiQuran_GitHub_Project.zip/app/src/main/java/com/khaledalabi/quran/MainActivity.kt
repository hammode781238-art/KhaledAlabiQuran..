package com.khaledalabi.quran

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Juz(val number: Int, val title: String, val url: String)

private val juzList = listOf(
        Juz(1, "الجزء الأول", "https://www.youtube.com/watch?v=8ppmuAgfK6k"),
        Juz(2, "الجزء الثاني", "https://www.youtube.com/watch?v=KpiJ83nv0hs"),
        Juz(3, "الجزء الثالث", "https://www.youtube.com/watch?v=3kdEcdDOz1M"),
        Juz(4, "الجزء الرابع", "https://www.youtube.com/watch?v=7LaLdDPP_YI"),
        Juz(5, "الجزء الخامس", "https://www.youtube.com/watch?v=bKcrxsSdhwM"),
        Juz(6, "الجزء السادس", "https://www.youtube.com/watch?v=6Eg3C5MhWpQ"),
        Juz(7, "الجزء السابع", "https://www.youtube.com/watch?v=w6TO-wfMksg"),
        Juz(8, "الجزء الثامن", "https://www.youtube.com/watch?v=BEsrWZemB9k"),
        Juz(9, "الجزء التاسع", "https://www.youtube.com/watch?v=oJOKCLHo5HE"),
        Juz(10, "الجزء العاشر", "https://www.youtube.com/watch?v=SkLi4QqZhBg"),
        Juz(11, "الجزء الحادي عشر", "https://www.youtube.com/watch?v=HNVn8UFNVnY"),
        Juz(12, "الجزء الثاني عشر", "https://www.youtube.com/watch?v=PsvxyO531Sc"),
        Juz(13, "الجزء الثالث عشر", "https://www.youtube.com/watch?v=ckUsl13xt3s"),
        Juz(14, "الجزء الرابع عشر", "https://www.youtube.com/watch?v=eMbojnBxwx0"),
        Juz(15, "الجزء الخامس عشر", "https://www.youtube.com/watch?v=rO5rkCHi3Pw"),
        Juz(16, "الجزء السادس عشر", "https://www.youtube.com/watch?v=ew1bQxiyT4M"),
        Juz(17, "الجزء السابع عشر", "https://www.youtube.com/watch?v=x4utBhLxl_Q"),
        Juz(18, "الجزء الثامن عشر", "https://www.youtube.com/watch?v=1Eyp0LXM0ms"),
        Juz(19, "الجزء التاسع عشر", "https://www.youtube.com/watch?v=NqnITmpsn8g"),
        Juz(20, "الجزء العشرون", "https://www.youtube.com/watch?v=FXhOXNHhmhI"),
        Juz(21, "الجزء الحادي والعشرون", "https://www.youtube.com/watch?v=rbyUzYO6TNk"),
        Juz(22, "الجزء الثاني والعشرون", "https://www.youtube.com/watch?v=RsZEZyVhspE"),
        Juz(23, "الجزء الثالث والعشرون", "https://www.youtube.com/watch?v=Y6qEhHvQ_F0"),
        Juz(24, "الجزء الرابع والعشرون", "https://www.youtube.com/watch?v=grUHALlZvIU"),
        Juz(25, "الجزء الخامس والعشرون", "https://www.youtube.com/watch?v=rizw2v6EwTA"),
        Juz(26, "الجزء السادس والعشرون", "https://www.youtube.com/watch?v=GcFVmGUXU-c"),
        Juz(27, "الجزء السابع والعشرون", "https://www.youtube.com/watch?v=uZ6QzdIfSNk"),
        Juz(28, "الجزء الثامن والعشرون", "https://www.youtube.com/watch?v=yIEXYzG-Hlo"),
        Juz(29, "الجزء التاسع والعشرون", "https://www.youtube.com/watch?v=-aIwOqkgQOI"),
        Juz(30, "الجزء الثلاثون", "https://www.youtube.com/watch?v=kS3E_NvGJEw")
)

private val DeepGreen = Color(0xFF0B3D32)
private val Emerald = Color(0xFF126B58)
private val Gold = Color(0xFFC7A44B)
private val Cream = Color(0xFFF7F3E8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { QuranApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuranApp() {
    var query by remember { mutableStateOf("") }
    var searchOpen by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Juz?>(null) }

    val filtered = juzList.filter {
        it.title.contains(query.trim(), ignoreCase = true) || it.number.toString() == query.trim()
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = DeepGreen,
            secondary = Gold,
            background = Cream,
            surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Cream,
            topBar = {
                if (searchOpen) {
                    TopAppBar(
                        title = {
                            OutlinedTextField(
                                value = query,
                                onValueChange = { query = it },
                                placeholder = { Text("ابحث عن الجزء…") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        },
                        navigationIcon = {
                            TextButton(onClick = { searchOpen = false; query = "" }) { Text("إلغاء") }
                        }
                    )
                } else {
                    TopAppBar(
                        title = {
                            Column {
                                Text("ختمة الشيخ خالد العلبي", fontWeight = FontWeight.Bold)
                                Text("القرآن الكريم • 30 جزءًا", fontSize = 12.sp, color = Color.Gray)
                            }
                        },
                        actions = {
                            IconButton(onClick = { searchOpen = true }) {
                                Icon(Icons.Default.Search, contentDescription = "بحث")
                            }
                            IconButton(onClick = { }) {
                                Icon(Icons.Default.Settings, contentDescription = "الإعدادات")
                            }
                        }
                    )
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.padding(padding).fillMaxSize(),
                contentPadding = PaddingValues(bottom = 28.dp)
            ) {
                item {
                    HeroHeader()
                }
                item {
                    Text(
                        "الأجزاء",
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = DeepGreen
                    )
                }
                items(filtered, key = { it.number }) { juz ->
                    JuzCard(juz) {
                        selected = juz
                    }
                }
                if (filtered.isEmpty()) {
                    item {
                        Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                            Text("لا توجد نتائج مطابقة", color = Color.Gray)
                        }
                    }
                }
            }
        }

        selected?.let { juz ->
            AlertDialog(
                onDismissRequest = { selected = null },
                title = { Text(juz.title, fontWeight = FontWeight.Bold) },
                text = {
                    Text("سيتم فتح التلاوة على YouTube. يمكنك الاستماع مباشرة من التطبيق الرسمي أو المتصفح.")
                },
                confirmButton = {
                    Button(onClick = {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(juz.url))
                        startActivity(intent)
                        selected = null
                    }) {
                        Icon(Icons.Default.PlayArrow, null)
                        Spacer(Modifier.width(8.dp))
                        Text("استماع الآن")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { selected = null }) { Text("إلغاء") }
                }
            )
        }
    }
}

@Composable
private fun HeroHeader() {
    Box(
        modifier = Modifier
            .padding(16.dp)
            .fillMaxWidth()
            .height(190.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(
                Brush.linearGradient(
                    listOf(DeepGreen, Emerald)
                )
            )
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Default.Book, null, tint = Gold, modifier = Modifier.size(42.dp))
            Spacer(Modifier.height(12.dp))
            Text("وَرَتِّلِ الْقُرْآنَ تَرْتِيلًا", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("استمع إلى الختمة المرتلة بصوت الحافظ الجامع الشيخ محمد خالد العلبي", color = Color.White.copy(alpha = .85f), fontSize = 14.sp)
        }
    }
}

@Composable
private fun JuzCard(juz: Juz, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(DeepGreen),
                contentAlignment = Alignment.Center
            ) {
                Text(juz.number.toString(), color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(juz.title, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = DeepGreen)
                Text("تلاوة مرتلة • الشيخ محمد خالد العلبي", fontSize = 12.sp, color = Color.Gray)
            }
            IconButton(onClick = onClick) {
                Icon(Icons.Default.PlayArrow, contentDescription = "تشغيل", tint = Gold)
            }
        }
    }
}
